<?php defined('SYSPATH') or die('No direct script access');
return array(
    'client_id' => '1064636737871-4asm4jhp13cd56lqq8h1fn2174irkfb3.apps.googleusercontent.com',
    'client_secret' => 'KVbrfm0DecnWnwoiv_P8AviT',
    'redirect_uri' => URL::site('admin/auth/goauth'),
    'none_avatar_img' => URL::site('img/photo.jpg')
);