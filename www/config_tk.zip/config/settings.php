<?php
/**
 * Developer: Roquie
 * Current file name: settings.php
 * 
 * All rights reserved (c)
 */

return Model::factory('Settings')->load();